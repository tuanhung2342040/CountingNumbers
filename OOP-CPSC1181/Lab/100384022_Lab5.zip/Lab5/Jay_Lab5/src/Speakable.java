public interface Speakable {

    void speak();
}
