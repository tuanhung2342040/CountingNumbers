public class negativeZeroAmountException extends RuntimeException{

    public negativeZeroAmountException(String msg){
        super(msg);
    }
}
