public class CPSC1181Exception extends RuntimeException{
    public CPSC1181Exception(){};
    public CPSC1181Exception(String msg){
        super(msg);
    }
}
